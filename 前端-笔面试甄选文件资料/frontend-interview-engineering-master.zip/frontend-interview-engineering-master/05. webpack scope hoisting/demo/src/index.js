import { getRandom } from './module';

for (let i = 1; i < 20; i++) {
  console.log(getRandom(1, 10));
}
