module.exports = {
  rules: {
    eqeqeq: 'error',
  },
};
