export function f3() {
  console.log("f3");
}

export function f4() {
  console.log("f4");
}
