import { f1 } from './modules/a';
import * as bFuncs from './modules/b';
f1();
bFuncs.f4();
