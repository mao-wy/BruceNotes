console.log("index1.js没有依赖其他模块，也没有导出任何东西");
