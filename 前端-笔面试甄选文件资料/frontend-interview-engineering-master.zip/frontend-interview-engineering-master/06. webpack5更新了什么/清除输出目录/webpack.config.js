module.exports = {
  mode: 'production',
  output: {
    clean: true,
  },
};
