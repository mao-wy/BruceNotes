const m = require('./1');
console.log(m);
