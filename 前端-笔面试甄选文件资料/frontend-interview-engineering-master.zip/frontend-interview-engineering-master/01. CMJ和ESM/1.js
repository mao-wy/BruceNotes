exports.a = 'a';
module.exports.b = 'b';
this.c = 'c';
module.exports = {
  d: 'd',
};
