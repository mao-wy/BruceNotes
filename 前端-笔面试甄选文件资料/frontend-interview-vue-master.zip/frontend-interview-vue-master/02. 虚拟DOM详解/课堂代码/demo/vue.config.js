module.exports = {
  runtimeCompiler: false,
};
