module.exports = {
  plugins: {
    tailwindcss: {
      purge: ['./src/**/*.vue'],
    },
    autoprefixer: {},
  },
};
