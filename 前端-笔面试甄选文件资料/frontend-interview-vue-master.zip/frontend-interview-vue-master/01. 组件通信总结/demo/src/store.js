export default {
  number: {
    value: 1,
  },
};
