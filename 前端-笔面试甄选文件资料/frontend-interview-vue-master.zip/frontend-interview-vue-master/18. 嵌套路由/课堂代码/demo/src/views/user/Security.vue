<template>
  <h1 class="text-2xl text-center font-bold">User Security</h1>
</template>
