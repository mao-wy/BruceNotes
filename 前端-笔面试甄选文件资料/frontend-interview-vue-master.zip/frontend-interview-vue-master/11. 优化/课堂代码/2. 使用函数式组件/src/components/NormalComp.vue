<template>
  <h1>NormalComp: {{ count }}</h1>
</template>

<script>
export default {
  props: {
    count: Number,
  },
};
</script>

<style></style>
