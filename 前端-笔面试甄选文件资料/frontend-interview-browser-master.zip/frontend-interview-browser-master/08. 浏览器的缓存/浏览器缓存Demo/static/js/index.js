const h1 = document.querySelector("h1");

h1.onclick = function(){
    window.alert("这是一个标题");
}