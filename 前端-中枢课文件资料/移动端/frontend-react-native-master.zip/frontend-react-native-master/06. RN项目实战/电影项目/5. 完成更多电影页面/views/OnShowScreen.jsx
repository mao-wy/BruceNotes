// 正在热映

import MoreMovie from "../components/MoreMovie"

export default function OnShowScreen({navigation}) {
    return <MoreMovie type="onshow" navigation={navigation}/>
}