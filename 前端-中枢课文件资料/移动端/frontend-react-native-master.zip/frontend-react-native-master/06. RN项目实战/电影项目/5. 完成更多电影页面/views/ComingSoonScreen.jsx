// 即将上映

// 正在热映
import MoreMovie from "../components/MoreMovie"

export default function ComingSoonScreen({navigation}) {
    return <MoreMovie type="comingsoon" navigation={navigation}/>
}