import loadImage from './loadImage.js';
import preloadImages from './preloadImages.js';
export default {
  loadImage,
  preloadImages
};