<template>
    <div>
        <p>预告片</p>
    </div>
</template>

<script>
export default {
    setup () {
        

        return {}
    }
}
</script>

<style scoped>
p {
  font-size: 0.4rem;
  margin: 4.5rem 0 0 .3rem;
}
</style>