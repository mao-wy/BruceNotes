export var classicMovieContent = `
    <p>经典电影部分内容</p>
`