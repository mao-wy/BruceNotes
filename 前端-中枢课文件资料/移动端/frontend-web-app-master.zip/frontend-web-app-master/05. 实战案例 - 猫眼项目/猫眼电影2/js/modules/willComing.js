export var willComingContent = `
    <p>待映部分内容</p>
`