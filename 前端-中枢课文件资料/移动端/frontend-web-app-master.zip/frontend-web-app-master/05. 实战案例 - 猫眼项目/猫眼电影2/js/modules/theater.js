export var theaterContent = `
<div class="swiper-wrapper">
<div class="swiper-slide slideContainer">
    <!-- 影院区域 -->
    <ul class="theaterArea">
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
        <li class="theaterContainer">
            <h3>嘉莱国际影城（金科路店）<span>19.9</span><span>元起</span></h3>
            <p>金牛区金科西路58号（负一楼）</p>
            <div class="label-block">
                <div class="allowRefund">退</div>
                <div class="endorse">改签</div>
                <div class="snack">小吃</div>
                <div class="vipTag">折扣卡</div>
            </div>
            <p class="discount">开卡特惠，17.9元起开卡</p>˝
        </li>
    </ul>
</div>
</div>
`