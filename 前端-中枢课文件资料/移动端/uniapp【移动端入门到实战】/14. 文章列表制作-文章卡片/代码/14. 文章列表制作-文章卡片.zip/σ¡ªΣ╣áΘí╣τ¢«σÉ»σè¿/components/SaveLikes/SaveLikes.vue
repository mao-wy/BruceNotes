<template>
	<view class="save-incons">
		<uni-icons color="#ff6600" type="heart-filled" size="20"></uni-icons>
	</view>
</template>

<script>
	export default {
		name:"SaveLikes",
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>
