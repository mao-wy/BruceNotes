import Fly from 'flyio/dist/npm/wx'
//创建对象
const fly = new Fly()
//暴露对象
export default fly