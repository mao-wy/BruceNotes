<template>
  <div>about index</div>
</template>

<script>
export default {
    onLoad(e){
        console.log("onLoad",e)
    },
    mounted(e){
        console.log("mounted",e)
    },
    data(){
        return{

        }
    },
    methods:{

    }
}
</script>

<style>

</style>