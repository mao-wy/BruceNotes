export default {
    albumList: [{
        name: '寂寞不痛',
        singer: 'A-Lin',
        image: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000000Nlo922ahOEE.jpg?max_age=2592000'
    }, {
        name: '喜剧之王',
        singer: '李荣浩',
        image: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000001FOctH2oGoAx.jpg?max_age=2592000'
    }, {
        name: 'I Know You Were Trouble.-Single',
        singer: 'Taylor Swift',
        image: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000000XafSm26FA1L.jpg?max_age=2592000'
    }, {
        name: '哎呦，不错哦',
        singer: '周杰伦',
        image: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000001uqejs3d6EID.jpg?max_age=2592000'
    }]
}