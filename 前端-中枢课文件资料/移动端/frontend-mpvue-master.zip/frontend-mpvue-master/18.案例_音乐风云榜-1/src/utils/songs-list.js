export default {
    songslist:[{
        dataUrl: 'http://mpge.5nd.com/2018/2018-5-10/85111/1.mp3',
        name: '哑巴',
        singer: '薛之谦',
        coverImgUrl: 'http://img.5nd.com/86/photo/2018album/20185/85111.jpg'
      }, {
        dataUrl: 'http://stream.qqmusic.tc.qq.com/138549169.mp3',
        name: '你还要我怎样',
        singer: '薛之谦',
        coverImgUrl: 'http://y.gtimg.cn/music/photo_new/T002R90x90M000000aWdOx24i3dG.jpg'
      }, {
        dataUrl: 'http://stream.qqmusic.tc.qq.com/137903929.mp3',
        name: '微微一笑很倾城',
        singer: '杨洋',
        coverImgUrl: 'http://y.gtimg.cn/music/photo_new/T002R90x90M000003RxTdZ0sJLwo.jpg'
      }, {
        dataUrl: 'http://stream.qqmusic.tc.qq.com/132636799.mp3',
        name: '演员',
        singer: '薛之谦',
        coverImgUrl: 'http://y.gtimg.cn/music/photo_new/T002R90x90M000003y8dsH2wBHlo.jpg'
      }]
}