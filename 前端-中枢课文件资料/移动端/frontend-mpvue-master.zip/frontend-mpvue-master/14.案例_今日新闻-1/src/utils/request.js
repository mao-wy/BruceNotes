import Fly from 'flyio/dist/npm/wx'
const fly = new Fly()

export default fly