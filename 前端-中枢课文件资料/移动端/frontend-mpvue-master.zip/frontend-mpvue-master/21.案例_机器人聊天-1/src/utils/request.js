import Fly from 'flyio/dist/npm/wx'
const fly = new Fly()

//暴露对象
export default fly