<template>
  <div class="page-bottom">
    <div class="page-content">
      <div class="wc">
        <a href="/pages/sliderIndex/main">旅游游玩</a>
      </div>
      <div class="wc">
        <a href="/pages/sliderTwo/main">酒店住宿（缩放）</a>
      </div>
      <div class="wc">
          <a href="/pages/sliderThree/main">风景名胜(拖动)</a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
    data(){
        return{

        }
    },
    methods:{}
};
</script> 

<style>

</style>