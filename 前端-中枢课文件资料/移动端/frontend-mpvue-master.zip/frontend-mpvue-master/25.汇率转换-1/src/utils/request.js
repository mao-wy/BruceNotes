import Fly from 'flyio/dist/npm/wx'
const fly = new Fly()

//暴露接口
export default fly