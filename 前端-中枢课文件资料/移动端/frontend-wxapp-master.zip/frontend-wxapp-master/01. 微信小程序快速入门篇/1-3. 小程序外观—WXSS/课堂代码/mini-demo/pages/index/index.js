// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    a : 10,
    b : 15,
    time : (new Date()).toString(),
    age : 20,
    fruits : ["苹果","香蕉","哈密瓜"],
    color: 'blue',
    eleFontsize: '48rpx'
  },
})
