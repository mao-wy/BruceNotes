// app.js
App({
  globalData: {
    userName: "谢杰"
  }
})


