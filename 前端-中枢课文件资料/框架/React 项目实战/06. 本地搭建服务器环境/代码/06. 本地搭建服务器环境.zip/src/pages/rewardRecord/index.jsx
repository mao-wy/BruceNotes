import React from 'react';

const rewardRecord = () => {
  return <div>奖惩记录</div>;
};

export default rewardRecord;
