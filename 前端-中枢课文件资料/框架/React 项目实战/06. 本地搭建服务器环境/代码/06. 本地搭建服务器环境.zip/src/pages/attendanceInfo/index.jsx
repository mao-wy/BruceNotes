import React from 'react';

const attendanceInfo = () => {
  return <div>考勤信息界面</div>;
};

export default attendanceInfo;
