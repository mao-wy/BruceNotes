import React from 'react';

const attendance = () => {
  return <div>出勤统计界面</div>;
};

export default attendance;
