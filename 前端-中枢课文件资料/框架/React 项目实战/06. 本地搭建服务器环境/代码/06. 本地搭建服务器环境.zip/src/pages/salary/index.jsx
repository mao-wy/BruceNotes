import React from 'react';

const salary = () => {
  return <div>调薪记录模块</div>;
};

export default salary;
