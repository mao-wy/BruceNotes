import React from 'react';

const assessment = () => {
  return <div>绩效考核界面</div>;
};

export default assessment;
