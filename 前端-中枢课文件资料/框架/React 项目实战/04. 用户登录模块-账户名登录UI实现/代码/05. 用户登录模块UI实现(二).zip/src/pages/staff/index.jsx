import React from 'react';

const staff = () => {
  return <div>员工管理界面</div>;
};

export default staff;
