import React from 'react';

const index = () => {
  return <div>公司情况分析界面</div>;
};

export default index;
