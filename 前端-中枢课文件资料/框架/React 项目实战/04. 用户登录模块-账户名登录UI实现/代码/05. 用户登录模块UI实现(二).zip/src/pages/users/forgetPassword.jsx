import React from 'react';

const forgetPassword = () => {
  return <div>忘记密码</div>;
};

export default forgetPassword;
