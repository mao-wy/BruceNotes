import React from 'react'

const DetailForm = () => {
  return (
    <div>
      员工详情表单
    </div>
  )
}

export default DetailForm
