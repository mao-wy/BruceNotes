// @ts-nocheck
import { plugin } from './plugin';
import * as Plugin_0 from '/Users/hangang/Documents/渡一教育/织信管理系统相关内容/课程代码/各版本代码/src/.umi/plugin-dva/runtime.tsx';
import * as Plugin_1 from '../plugin-initial-state/runtime';
import * as Plugin_2 from '../plugin-model/runtime';

  plugin.register({
    apply: Plugin_0,
    path: '/Users/hangang/Documents/渡一教育/织信管理系统相关内容/课程代码/各版本代码/src/.umi/plugin-dva/runtime.tsx',
  });
  plugin.register({
    apply: Plugin_1,
    path: '../plugin-initial-state/runtime',
  });
  plugin.register({
    apply: Plugin_2,
    path: '../plugin-model/runtime',
  });

export const __mfsu = 1;
