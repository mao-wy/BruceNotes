// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from '/Users/hangang/Documents/渡一教育/织信管理系统相关内容/课程代码/各版本代码/node_modules/umi/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/components/Loading';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__index' */'@/layouts/index.js'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/404Page",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404Page__index' */'@/pages/404Page/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/assessment",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__assessment__index' */'@/pages/assessment/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/attendance",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__attendance__index' */'@/pages/attendance/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/attendanceInfo",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__attendanceInfo__index' */'@/pages/attendanceInfo/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/dashboard",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__dashboard__index' */'@/pages/dashboard/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/department",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__department__index' */'@/pages/department/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__index' */'@/pages/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/level",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__level__index' */'@/pages/level/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/rewardAndPunishment",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__rewardAndPunishment__index' */'@/pages/rewardAndPunishment/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/salary",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__salary__index' */'@/pages/salary/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/staff",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__staff__index' */'@/pages/staff/index.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/users/forgetPassword",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__users__forgetPassword' */'@/pages/users/forgetPassword.jsx'), loading: LoadingComponent})
      },
      {
        "path": "/users/login",
        "exact": true,
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__users__login' */'@/pages/users/login.jsx'), loading: LoadingComponent})
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
