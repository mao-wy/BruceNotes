export const mapData = {
  gender: ['男', '女'],
  marriage: ['已婚', '未婚'],
  education: ['专科', '本科', '硕士', '博士', '博士后', '留学生'],
  rewardType: ['优秀员工', '知识创新', '通报批评', '警告处分'],
};
