import React from 'react';

const index = () => {
  return <div>123</div>;
};

export default index;
