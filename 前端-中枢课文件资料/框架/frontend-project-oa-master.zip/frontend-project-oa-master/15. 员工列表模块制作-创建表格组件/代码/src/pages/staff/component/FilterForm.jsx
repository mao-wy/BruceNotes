import React from 'react';

const FilterForm = () => {
  return <div>搜索表单</div>;
};

export default FilterForm;
