import React from 'react';

const login = () => {
  return <div>登录界面</div>;
};

export default login;
