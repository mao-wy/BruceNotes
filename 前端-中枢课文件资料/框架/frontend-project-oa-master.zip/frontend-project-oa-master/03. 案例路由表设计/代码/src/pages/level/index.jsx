import React from 'react';

const level = () => {
  return <div>职级管理界面</div>;
};

export default level;
