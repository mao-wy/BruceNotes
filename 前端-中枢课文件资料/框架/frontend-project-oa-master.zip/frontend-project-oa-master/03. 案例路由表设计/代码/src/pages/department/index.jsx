import React from 'react';

const department = () => {
  return <div>员工管理界面</div>;
};

export default department;
