import React from 'react';

const LoginLayout = ({ children }) => {
  return <>{children}</>;
};

export default LoginLayout;
