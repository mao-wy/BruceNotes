// @ts-nocheck
import { Plugin } from '/Users/hangang/Documents/渡一教育/织信管理系统相关内容/课程代码/各版本代码/node_modules/umi/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','getInitialState','initialStateConfig','request',],
});

export { plugin };
