import React from 'react';

const rewardAndPunishment = () => {
  return <div>奖惩记录</div>;
};

export default rewardAndPunishment;
