import React from 'react';

const department = () => {
  return <div>部门管理</div>;
};

export default department;
