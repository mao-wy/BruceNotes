import React from 'react'
import {Button} from 'antd'

const test = () => {
  return (
    <div>
      hello test page
      <Button type="primary">button</Button>
    </div>
  )
}

export default test
