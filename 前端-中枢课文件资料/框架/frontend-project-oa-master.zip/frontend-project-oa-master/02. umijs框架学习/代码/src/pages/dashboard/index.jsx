import React from 'react'

const index = () => {
  return (
    <div>
      图表界面-dashboard
    </div>
  )
}

export default index
