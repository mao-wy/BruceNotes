export const URLs = {
  likeSearch: '/likeSearch',
  getSide: '/getsidebar',
  getGoodsList: '/getGoodsList',
  // '/getgoodsList',
  search: '/search',
  getGoodsByIds: '/getGoodsByIds',
};
// const baseURL = 'https://mock.duyiedu.com/mock/12/phone';
// const baseURL = 'http://localhost:3333/goods/';
const baseURL = 'https://mallapi.duyiedu.com/goods/';

export default baseURL;
