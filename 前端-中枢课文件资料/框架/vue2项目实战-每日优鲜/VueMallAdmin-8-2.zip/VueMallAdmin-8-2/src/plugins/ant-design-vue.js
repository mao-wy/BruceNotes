import Vue from 'vue';
import Antd from 'ant-design-vue';
import '../antd-variables.less';

Vue.use(Antd);
