import React from 'react';
import ReactDOM from 'react-dom';
// import Tick from "./components/Tick"
import A from "./components/Test"

// ReactDOM.render(<Tick number={10} />, document.getElementById('root'));

ReactDOM.render(<A/>, document.getElementById('root'))
