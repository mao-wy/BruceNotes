import React, { Component } from 'react'
import FormTest from "./components/FormTest"

export default class App extends Component {


    render() {
        return <FormTest />
    }
}
