import React from 'react';
import ReactDOM from 'react-dom';
import Comp from './Comp'

ReactDOM.render(<Comp/>, document.getElementById('root'));
