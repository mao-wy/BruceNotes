import React from 'react'
// import FuncDefault from "./FuncDefault"
import ClassDefault from "./ClassDefault"
export default function App() {
    return (
        <div>
            {/* <FuncDefault a={10} b={20}/> */}
            <ClassDefault a={10} b={20}/>
        </div>
    )
}