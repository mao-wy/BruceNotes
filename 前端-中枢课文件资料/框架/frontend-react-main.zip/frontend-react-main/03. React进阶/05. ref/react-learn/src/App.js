import React from 'react'
import Comp from "./components/Comp"

export default function App() {
    return (
        <div>
            <Comp/>
        </div>
    )
}
