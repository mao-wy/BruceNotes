import React from 'react'
import Test from "./components/common/Form/Test"

export default function App() {
    return (
        <Test />
    )
}
