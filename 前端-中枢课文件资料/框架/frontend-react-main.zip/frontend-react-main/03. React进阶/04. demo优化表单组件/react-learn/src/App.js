import React from 'react'
import Test from "./components/common/Select/Test"

export default function App() {
    return (
        <div>
            <Test/>
        </div>
    )
}
