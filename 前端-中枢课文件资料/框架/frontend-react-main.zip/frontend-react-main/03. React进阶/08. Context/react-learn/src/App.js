import React from 'react'
// import OldContext from "./OldContext";
import NewContext from "./NewContext"
export default class App extends React.Component {
    render() {
        return (
            <NewContext />
        )
    }
}
