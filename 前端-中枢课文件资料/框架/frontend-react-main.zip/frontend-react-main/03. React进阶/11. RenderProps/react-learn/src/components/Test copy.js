import MovablePanel from "./MovablePanel"
import ShowMousePoint from "./ShowMousePoint"
import React from 'react'

export default function Test() {
    return (
        <div>
            <MovablePanel />
            <ShowMousePoint/>
        </div>
    )
}
