// var util = require("./util")

// var arr = [6,4,3,2,6,8,8,32,5];

// util.sortRandom(arr);

// console.log(arr);

var Poker = require("./poker")

var p = new Poker(4, 11);
console.log(p.toString());