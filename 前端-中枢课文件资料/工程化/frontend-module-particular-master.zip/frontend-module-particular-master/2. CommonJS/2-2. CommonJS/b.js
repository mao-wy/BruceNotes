console.log("b模块执行了！")

var u = require("./util");

console.log(u.abc);