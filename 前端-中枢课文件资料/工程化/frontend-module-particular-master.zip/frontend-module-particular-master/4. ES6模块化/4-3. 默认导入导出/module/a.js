export var a = 1;
export var b = 2;

export default {
    fn: function () { },
    name: "adsfaf"
}