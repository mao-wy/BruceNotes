export const a = "m2-a";
export const k = "m2-k";
export const t = "m2-t";

export default "m2-default";

/*
{
    a:xx,
    k:xx,
    t:xx,
    default:xxx
}
*/