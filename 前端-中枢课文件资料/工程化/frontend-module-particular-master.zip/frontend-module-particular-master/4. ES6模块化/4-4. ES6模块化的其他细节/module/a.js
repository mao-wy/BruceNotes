export var name = "模块a";

export default function () {
    name = "module a";
}