// // import method, { name } from "./a.js"

// // console.log(name)
// // method();
// // console.log(name)

// import "./arrayPatcher.js"

// var arr = [3,4,6,6,7];
// arr.print();

import * as m from "./m.js"

console.log(m)