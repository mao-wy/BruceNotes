var b = require("b");
console.log("我是a模块，得到b模块的内容：", b);