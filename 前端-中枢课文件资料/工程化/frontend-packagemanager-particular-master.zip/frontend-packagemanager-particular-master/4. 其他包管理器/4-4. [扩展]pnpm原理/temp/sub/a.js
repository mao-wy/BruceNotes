console.log(__dirname);

var b = require("../b")
console.log("b模块的内容：", b);