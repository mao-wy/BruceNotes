var func = require("testabcd1234")
var newArr = func([45,7,0,false,"",21])
console.log(newArr)