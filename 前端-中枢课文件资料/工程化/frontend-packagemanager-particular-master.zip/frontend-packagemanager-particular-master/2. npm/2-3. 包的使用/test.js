var test = require("lodash/fp/add")

console.log(test)