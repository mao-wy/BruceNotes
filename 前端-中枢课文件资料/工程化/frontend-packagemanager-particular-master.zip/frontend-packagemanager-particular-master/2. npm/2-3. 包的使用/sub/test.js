var $ = require("jquery")

console.log($)