class A {
    method() {

    }
}