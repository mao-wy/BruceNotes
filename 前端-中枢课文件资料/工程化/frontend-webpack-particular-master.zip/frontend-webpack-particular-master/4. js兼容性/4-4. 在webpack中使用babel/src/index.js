const func = () => {
    console.log("abc");
}

func();

new Promise(resolve => {
    resolve();
})

async function method(){
    
}