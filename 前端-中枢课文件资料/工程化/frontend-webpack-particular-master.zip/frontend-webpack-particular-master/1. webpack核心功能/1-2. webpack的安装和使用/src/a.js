require("./b")
console.log("module a")