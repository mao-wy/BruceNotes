require("./a")
console.log("hello webpack");