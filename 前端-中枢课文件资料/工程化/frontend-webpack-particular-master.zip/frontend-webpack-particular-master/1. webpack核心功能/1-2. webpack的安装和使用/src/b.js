import "./c"

console.log("module a")