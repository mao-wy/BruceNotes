console.log("es6 module c")
import $ from "jquery"
console.log($);
export default "c";