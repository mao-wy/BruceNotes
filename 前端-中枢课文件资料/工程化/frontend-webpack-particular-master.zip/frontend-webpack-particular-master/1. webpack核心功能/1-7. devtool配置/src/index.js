require("./a")
console.log("index module")