var obj = null;
obj.abc();
console.log("a module")