module.exports = {
    mode: "production",
    devtool: "hidden-source-map"
}