import b from "./b.js"
console.log("a")
export default "a"