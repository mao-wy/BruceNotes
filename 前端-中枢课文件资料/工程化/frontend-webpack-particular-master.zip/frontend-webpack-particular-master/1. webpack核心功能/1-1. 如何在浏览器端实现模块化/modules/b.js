// import $ from "../node_modules/jquery/dist/jquery.js";
// require("jquery")
console.log("b")
export default "b";