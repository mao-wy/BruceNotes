// var obj = require("./es6a")
// console.log(obj.a, obj.b, obj.default)

// import * as obj from "./commonjsa"
// import obj from "./commonjsa"

// console.log(obj)

//jquery
//module.exports = function(){}

// var $ = require("jquery")
// console.log($)

// import $ from "jquery"
// console.log($);

var obj = require("./es6a")
console.log(obj)