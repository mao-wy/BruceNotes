// export var a = 1;
// export var b = 2;
// export default 3;

export default {
    a: 1,
    b: 2,
    c: 3
}