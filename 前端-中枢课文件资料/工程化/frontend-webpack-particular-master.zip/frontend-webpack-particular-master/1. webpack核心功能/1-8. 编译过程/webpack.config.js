module.exports = {
    mode: "development",
    devtool: "source-map"
}