require("./b")
console.log("a")
module.exports = "a"