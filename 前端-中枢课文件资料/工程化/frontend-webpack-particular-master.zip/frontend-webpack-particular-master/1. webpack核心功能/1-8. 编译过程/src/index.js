console.log("index")
require("./a");
require("./b")