var content = require("./assets/index.css")

console.log(content); //css的源码字符串