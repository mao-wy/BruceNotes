console.log("index module")
var a = require("./a")
a.abc();
console.log(a)