
console.log("module a")
module.exports = "a";