module.exports = {
    mode: "production",
    devtool: "none"
}