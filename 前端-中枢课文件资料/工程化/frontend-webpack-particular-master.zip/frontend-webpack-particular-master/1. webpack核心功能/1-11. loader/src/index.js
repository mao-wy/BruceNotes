// 未知数 a = 1;
// 未知数 b = 3
require("./a");
