请求地址：http://yuanjin.tech:5100/api/local

method：GET

query：

- parentId: 可选，若不填，则查询所有省份，若填写省份id，则查询省份下的所有城市