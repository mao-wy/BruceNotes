// console.log(PI);
// console.log(VERSION);
// console.log(DOMAIN);

var r1 = $('#item'); // <= 起作用
var r2 = _.drop([1, 2, 3], 2); // <= 起作用
console.log(r1, r2);