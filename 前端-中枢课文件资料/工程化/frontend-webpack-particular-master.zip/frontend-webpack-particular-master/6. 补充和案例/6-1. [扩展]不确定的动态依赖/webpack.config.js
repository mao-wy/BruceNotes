module.exports = {
  mode: "development",
  devtool: "source-map",
  watch: true,
};
