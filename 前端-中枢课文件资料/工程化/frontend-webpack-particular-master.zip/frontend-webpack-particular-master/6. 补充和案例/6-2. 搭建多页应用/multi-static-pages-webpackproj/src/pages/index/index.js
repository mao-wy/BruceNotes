// 首页使用的js

// 引入公共css
import "../common/reset.css";
import "./index.css";
import "@/assets/global.css";

// 引入页面公共部分的js
import "../common/header";
import "../common/footer";

console.log("首页");
