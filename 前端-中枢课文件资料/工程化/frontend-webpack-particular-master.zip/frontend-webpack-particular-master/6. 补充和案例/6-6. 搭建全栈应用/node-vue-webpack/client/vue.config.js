module.exports = {
  outputDir: "../dist/public",
};
