module.exports = {
  presets: ["vue"],
};
