import styles from "./assets/index.less"
var div = document.getElementById("app");
div.className = styles.main;