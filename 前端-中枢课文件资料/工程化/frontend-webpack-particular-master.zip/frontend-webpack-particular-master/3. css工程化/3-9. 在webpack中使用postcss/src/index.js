import styles from  "./assets/index.pcss";
console.log(styles)