import style1 from  "./assets/style1.css"
import style2 from "./assets/style2.css"

console.log(style1)

const div1 = document.getElementById("div1");
div1.className = style2.c1;