require("./assets/banner.css")

console.log(result)
