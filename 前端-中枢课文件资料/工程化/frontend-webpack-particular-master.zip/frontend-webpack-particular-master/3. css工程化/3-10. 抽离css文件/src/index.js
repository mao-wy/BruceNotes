import styles from  "./assets/index.css";

var div = document.createElement("div");
div.className = styles.main;
document.body.appendChild(div);