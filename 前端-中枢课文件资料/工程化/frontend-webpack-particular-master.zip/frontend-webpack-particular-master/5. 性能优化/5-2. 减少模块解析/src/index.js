import $ from "./test"
console.log($);