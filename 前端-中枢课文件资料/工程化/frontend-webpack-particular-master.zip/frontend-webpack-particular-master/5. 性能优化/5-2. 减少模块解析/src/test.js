import $ from "jquery"

export default $;