module.exports = {
    mode: "development",
    devtool: "source-map",
    module: {
        noParse: /test/
    }
}