var foo = Math.random();
if (foo) foo++;
