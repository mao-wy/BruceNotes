var cpus = require("os").cpus();
console.log(cpus.length)