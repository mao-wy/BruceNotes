import _ from "lodash";

const obj = {
  0: "a",
  1: "b"
};

const result = _.isArray(obj);
console.log(result);