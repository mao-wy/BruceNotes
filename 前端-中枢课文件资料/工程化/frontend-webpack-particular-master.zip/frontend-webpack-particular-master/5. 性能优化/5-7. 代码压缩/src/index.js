import "./index.css";

const a = "abc";
const b = "bcd";
const c = a + b;
