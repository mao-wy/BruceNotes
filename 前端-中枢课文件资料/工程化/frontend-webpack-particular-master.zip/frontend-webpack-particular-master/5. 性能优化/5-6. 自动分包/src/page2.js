import $ from "jquery"
import _ from "lodash"
import common from "./common"
import "./common.css"
import "./page2.css"

console.log("page2")