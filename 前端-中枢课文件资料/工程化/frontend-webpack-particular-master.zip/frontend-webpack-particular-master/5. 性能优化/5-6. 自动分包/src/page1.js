import $ from "jquery"
import _ from "lodash"
import common from "./common"
import "./common.css"
import "./page1.css"

console.log("page1")