import $ from "jquery" 
import _ from "lodash"

const result = _.isArray($(".red"))
console.log(result);