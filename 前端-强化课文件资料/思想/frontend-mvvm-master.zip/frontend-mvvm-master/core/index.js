import Due from "./instance/index.js";

export default Due;