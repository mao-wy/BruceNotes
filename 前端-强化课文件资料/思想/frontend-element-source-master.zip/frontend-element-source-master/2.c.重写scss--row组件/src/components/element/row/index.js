import Row from './src/Row';

Row.install = (Vue) => {
  Vue.component(Row.name, Row);
};

export default Row;
