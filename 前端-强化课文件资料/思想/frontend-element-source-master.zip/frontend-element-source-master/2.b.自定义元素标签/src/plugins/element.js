import Vue from 'vue';
import Element from '@element';
import '@/assets/theme-chalk/index.scss';
import '@/assets/theme-chalk/display.scss';

Vue.use(Element);