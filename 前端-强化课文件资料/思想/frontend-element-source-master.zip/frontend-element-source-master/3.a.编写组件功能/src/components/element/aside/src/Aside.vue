<template>
  <div class="el-aside">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'ElAside',
};
</script>
