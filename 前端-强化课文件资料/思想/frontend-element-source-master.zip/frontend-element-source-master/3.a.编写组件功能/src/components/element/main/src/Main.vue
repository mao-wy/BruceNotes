<template>
  <div class="el-main">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'ElMain',
};
</script>
