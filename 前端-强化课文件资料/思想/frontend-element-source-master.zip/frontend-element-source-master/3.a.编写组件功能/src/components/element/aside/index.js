import Aside from './src/Aside.vue';

Aside.install = (Vue) => {
  Vue.component(Aside.name, Aside);
};

export default Aside;
