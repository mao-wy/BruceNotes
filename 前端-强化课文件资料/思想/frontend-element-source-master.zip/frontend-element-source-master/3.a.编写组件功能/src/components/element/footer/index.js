import Footer from './src/Footer.vue';

Footer.install = (Vue) => {
  Vue.component(Footer.name, Footer);
};

export default Footer;
