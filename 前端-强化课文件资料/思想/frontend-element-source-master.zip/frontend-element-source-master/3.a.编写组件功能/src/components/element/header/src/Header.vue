<template>
  <div class="el-header">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'ElHeader',
};
</script>
