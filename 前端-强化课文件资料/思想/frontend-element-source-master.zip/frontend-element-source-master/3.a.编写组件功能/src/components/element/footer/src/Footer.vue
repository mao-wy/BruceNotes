<template>
  <div class="el-footer">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'ElFooter',
};
</script>
