<template>
  <button>
    <slot></slot>
  </button>
</template>

<script>
export default {
  name: 'ElButton',
};
</script>
