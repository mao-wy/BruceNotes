import React from "react";

export default function index() {
  return (
    <div>
      <h1>电影列表</h1>
    </div>
  );
}
