import React from 'react'

export default function index() {
  return (
    <div>
      <h1>系统管理</h1>
    </div>
  )
}
