import React from 'react'

export default function index() {
  return (
    <div>
      <h1>admin：not found</h1>
    </div>
  )
}
