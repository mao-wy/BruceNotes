export default ({ router }) => {
  console.log(router);
  return <h1>多段动态路由</h1>;
};
