import React from 'react'
import Home from "@/pages/Home";

export default () => {
  return <Home />
}
