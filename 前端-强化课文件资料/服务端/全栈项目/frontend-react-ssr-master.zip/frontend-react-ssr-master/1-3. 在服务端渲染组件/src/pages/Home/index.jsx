import React from "react";

export default function() {
  return <h1>Home 页面</h1>;
}
