import Head from "next/head"

export default () => {
  console.log("movies render")
  return <div>
    <Head>
      <title>电影页</title>
    </Head>
    <h1>电影页</h1>
  </div>
}
