import Head from "next/head";

export default () => {
  return (
    <div>
      <Head>
        <title>首页</title>
      </Head>
      <h1>Index 首页</h1>
    </div>
  );
};
