import React from "react";
import Home from "@/pages/Home";
import "../assets/global.css";

export default () => {
  return <Home />;
};
