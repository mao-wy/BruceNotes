export default () => {
  return <h1>电影页</h1>
}
