export default () => {
  return <h1>Page1</h1>
}
