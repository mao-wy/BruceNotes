<template>
  <div id="app">
    <h1>我是一个vue组件</h1>
    <router-link to="/">首页</router-link>
    <router-link to="/demo">Demo</router-link>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
 
}
</script>

<style>

</style>