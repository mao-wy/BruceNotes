<template>
  <div>
    <div class="nav">
      <nuxt-link to="/">首页</nuxt-link>
      <nuxt-link to="/about">关于</nuxt-link>
      <nuxt-link to="/article">文章</nuxt-link>
      <nuxt-link to="/other">其他</nuxt-link>
    </div>
    <nuxt/>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
