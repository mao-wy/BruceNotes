<template>
  <div id="app">
    <h1>我是一个vue组件</h1>
    <demo />
  </div>
</template>

<script>
import demo from './components/demo.vue';
export default {
  components: {
    demo
  }
}
</script>

<style>

</style>