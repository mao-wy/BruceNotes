import createApp from '../main.js';

export default function () {
  const { app } = createApp();
  return app;
}