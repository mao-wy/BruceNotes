import createApp from '../main.js';

const { app } = createApp();
app.$mount('#app');
