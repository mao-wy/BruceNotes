# Vue SSR 环境搭建

## 上次课遗留的两个问题！
1. 开发环境问题 （利用webpack实现一个开发vue的环境）get
> 安装依赖：
> webpack: webpack webpack-cli webpack-dev-server webpack-merge
> vue: vue vue-loader vue-template-compiler vue-server-renderer
> js: babel-loader @babel/core @babel/preset-env
> css: vue-style-loader css-loader
> other: express html-webpack-plugin
2. 页面失活

