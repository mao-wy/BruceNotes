<template>
  <h1>我是about页面</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
