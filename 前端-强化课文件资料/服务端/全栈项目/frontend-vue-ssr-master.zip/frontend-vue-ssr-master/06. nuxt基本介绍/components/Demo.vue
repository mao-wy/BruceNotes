<template>
  <h1>Nuxtjs 你好</h1>
</template>

<script>
export default {

}
</script>

<style>

</style>
