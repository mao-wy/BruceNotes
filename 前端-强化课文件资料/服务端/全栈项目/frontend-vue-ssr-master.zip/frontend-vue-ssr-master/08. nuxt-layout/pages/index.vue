<template>
  <Tutorial/>
</template>

<script>
export default {
  layout: 'my-layout'
}
</script>
