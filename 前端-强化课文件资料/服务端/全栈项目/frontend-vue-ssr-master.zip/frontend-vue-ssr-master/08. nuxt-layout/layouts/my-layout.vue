<template>
  <div>
    <h1>我是自定义布局</h1>
    <nuxt/>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
