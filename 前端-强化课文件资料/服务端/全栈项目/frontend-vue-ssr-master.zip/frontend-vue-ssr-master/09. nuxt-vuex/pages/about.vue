<template>
  <h1>About页面</h1>
</template>

<script>
export default {
  middleware: 'auth',
}
</script>

<style>

</style>
