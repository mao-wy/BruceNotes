// store.state.todos.abd
export const state= () => ({
  abd: '123'
});
