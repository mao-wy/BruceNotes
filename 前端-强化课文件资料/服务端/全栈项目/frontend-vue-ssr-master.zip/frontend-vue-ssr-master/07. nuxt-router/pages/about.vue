<template>
  <div>
    <h1>about页面</h1>
    <nuxt-link to='/'>首页</nuxt-link>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
