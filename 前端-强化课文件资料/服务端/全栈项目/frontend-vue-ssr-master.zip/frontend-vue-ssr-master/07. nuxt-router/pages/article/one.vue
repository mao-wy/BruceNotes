<template>
  <div>我是一篇文章</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
