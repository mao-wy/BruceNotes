UPDATE student SET `name`='邓旭名' 
WHERE id=12;