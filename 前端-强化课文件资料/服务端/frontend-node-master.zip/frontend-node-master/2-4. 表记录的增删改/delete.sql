DELETE FROM student
WHERE `name`='袁哥';