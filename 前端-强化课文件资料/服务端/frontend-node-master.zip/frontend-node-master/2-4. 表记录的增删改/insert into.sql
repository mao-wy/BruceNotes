-- 增加语句

INSERT INTO `student`(stuno,`name`, birthday,sex,phone,classid)
VALUES('500', '成哥', '1900-1-1', TRUE, '13344445555', 2);

INSERT INTO `student`(stuno,`name`, birthday,phone,classid)
VALUES('500', '成哥', '1900-1-1', '13344445555', 2);

INSERT INTO `student`(stuno,`name`, birthday,phone,classid)
VALUES('500', '成哥', '1900-1-1', '13344445555', 2),
('501', '邓哥', '1900-1-2', '13344445556', 2);


