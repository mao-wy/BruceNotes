// console.log("src index module");

// console.log(module);

console.log(require)
