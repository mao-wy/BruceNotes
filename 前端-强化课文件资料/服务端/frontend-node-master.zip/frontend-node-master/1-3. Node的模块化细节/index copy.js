// require("D:\\repository\\NodeJS\\源码\\a.js");
// const result = require("./ab");
// console.log(result);

// require("abc");

// require("./src");

// require("abc/index")

// require("./src");

require("./src")
