这里面搭建vue工程（react）

1. 配置build的路径，把build之后的代码放到../public中
2. 或者，改动服务器的静态资源目录，改动到client/dist目录中