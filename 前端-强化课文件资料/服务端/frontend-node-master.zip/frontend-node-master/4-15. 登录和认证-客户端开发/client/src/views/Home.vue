<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <h1>这是首页，能匿名访问</h1>
  </div>
</template>

