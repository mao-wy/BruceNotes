-- 所有员工分布的地址

select DISTINCT location from employee;