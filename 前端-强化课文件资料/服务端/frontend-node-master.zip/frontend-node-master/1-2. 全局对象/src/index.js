// const buffer = Buffer.from("abcdefg", "utf-8");
// console.log(buffer);
// console.log("当前命令行：", process.cwd());


