// console.log(__dirname);

// console.log("当前命令行：", process.cwd());

// setTimeout(() => {
//   console.log("abc");
// }, 1000);

// process.exit();

// console.log(process.argv);

// console.log(process.platform);

// process.kill(10428);

console.log(process.env.ANDROID_HOME);
