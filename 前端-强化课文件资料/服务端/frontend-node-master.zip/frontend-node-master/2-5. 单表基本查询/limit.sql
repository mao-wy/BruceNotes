SELECT * from employee
limit 2,3;