const os = require("os");

// console.log(os.EOL);

// console.log(os.arch())

// console.log(os.cpus().length);

// console.log(os.freemem() / 2 ** 30);

// console.log(os.homedir());

// console.log(os.hostname());

console.log(os.tmpdir());
