require("./models/relation");
require("./mock/mockStudent");
