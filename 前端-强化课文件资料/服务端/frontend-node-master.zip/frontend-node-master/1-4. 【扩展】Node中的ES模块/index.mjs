import("./a.mjs").then(r => console.log(r));
