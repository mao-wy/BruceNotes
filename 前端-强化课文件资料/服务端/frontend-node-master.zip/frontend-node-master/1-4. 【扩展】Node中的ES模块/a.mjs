export default 5
export const a = 1;

// exports.b = 3;
// exports.a = 5;
