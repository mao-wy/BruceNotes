egg 脚手架 `create-egg`: https://www.npmjs.com/package/create-egg

