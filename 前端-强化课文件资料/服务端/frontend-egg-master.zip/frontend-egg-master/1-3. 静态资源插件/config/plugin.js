exports.static = {
  enable: true,
  package: "egg-static",
};
