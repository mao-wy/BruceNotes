exports.keys = "duyi.com";

exports.static = {
  prefix: "/",
  alias: {
    "/": "/index.html",
  },
};
