module.exports = {
  axios: require("axios").default,
  foo() {
    return "bar";
  },
};
