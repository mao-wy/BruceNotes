exports.ejs = {
  enable: true,
  package: "egg-view-ejs",
};
