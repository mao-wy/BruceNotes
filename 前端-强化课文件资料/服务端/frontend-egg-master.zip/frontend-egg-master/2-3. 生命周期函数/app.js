module.exports = class {
  constructor(app) {
    this.app = app;
  }
};
