# egg的其他功能

- [文件上传](https://eggjs.org/zh-cn/basics/controller.html#获取上传的文件)
- [国际化I18n](https://eggjs.org/zh-cn/core/i18n.html)
- [helper对象](https://eggjs.org/zh-cn/basics/objects.html#helper)
- [验证](https://eggjs.org/zh-cn/basics/controller.html#参数校验)

