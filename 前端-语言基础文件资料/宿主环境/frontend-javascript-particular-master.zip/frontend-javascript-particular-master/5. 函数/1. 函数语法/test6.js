
/**
 * nums：一个数字的数组
 */
var nums = [23, 56, 65, 746];

/**
 * 两个求和
 * @param {number} a 第一个数字
 * @param {number} b 第二个数字
 * @returns {number} 相加的结果
 */
function sum(a, b) {
    return a + b;
}

/**
 * 判断一个数是不是素数
 * @param {number} n 要判断的数
 * @returns {boolean} 是否是素数
 */
function isPrime(n){
    //..
}

var s = sum(1,3);