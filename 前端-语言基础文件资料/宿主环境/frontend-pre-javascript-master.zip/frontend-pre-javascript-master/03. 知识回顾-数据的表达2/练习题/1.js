var name = '邓哥';
var age = 60;
var sex = '男'
// 把上面三个数据组装成一个对象，对象的属性名和变量名相同
