(function () {
  console.log(abc.d);
  abc.c();
})();
