// name转换成驼峰命名
var name = 'has own property'; // --> hasOwnProperty
