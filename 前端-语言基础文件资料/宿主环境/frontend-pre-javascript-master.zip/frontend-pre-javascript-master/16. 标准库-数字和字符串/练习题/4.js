// 将下面的rgb格式转换成为HEX格式
var rgb = 'rgb(253, 183, 25)';
