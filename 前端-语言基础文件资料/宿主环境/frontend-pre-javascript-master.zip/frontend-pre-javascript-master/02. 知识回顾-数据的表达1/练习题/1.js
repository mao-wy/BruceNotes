// 下面的变量命名哪些是合法的

/* 


$ 
_
1$ 
list-style
list_style
list style
$$ 
$emit
var


*/
