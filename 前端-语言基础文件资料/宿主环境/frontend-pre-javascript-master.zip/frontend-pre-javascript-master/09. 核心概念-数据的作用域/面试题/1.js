// 下面的代码输出什么
// 下面的代码输出什么

console.log(a, b, c);
var a = 1;
var b = function () {};
function c() {}
