function m() {}

console.log(m.prototype);
