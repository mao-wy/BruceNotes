// 将下面多个数组拼接成一个数组

var nums1 = [1, 2, 3];
var nums2 = [4, 5, 6];
var nums3 = [7, 8, 9];
