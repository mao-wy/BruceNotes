var arr = [1, 23, 4534];
console.log(arr);
