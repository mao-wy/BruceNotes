var obj = {
  a: 1,
  b: 2,
};

obj.__proto__ = null;

clg;
