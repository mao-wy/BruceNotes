Function.prototype.isFunc = true;

function sum() {}

var obj = {};

console.log(obj.isFunc);
