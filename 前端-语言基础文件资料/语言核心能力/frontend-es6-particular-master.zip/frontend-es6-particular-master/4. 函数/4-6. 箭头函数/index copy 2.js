const print = num => {
    console.log("给我的数字是：", num)
}

print(2);