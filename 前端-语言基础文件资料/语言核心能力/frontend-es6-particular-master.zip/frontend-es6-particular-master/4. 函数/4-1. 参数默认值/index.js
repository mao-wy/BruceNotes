function test(a = b, b) {
    console.log(a, b);
}

test(undefined, 2);